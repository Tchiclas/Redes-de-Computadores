'''
everything related to the central server 

'''
import socket
import sys

HOST = socket.gethostname()

#o valor generico sera 58000 mais o numero do grupo
GN = 63  #GN sera o numero do grupo


#dicionario com o username como key
users = {}

#------chamar no inicio
def parse():

	#definir o PORT
	if(len(sys.argv) != 1 and sys.argv[1] == "-p"):
		PORT = int(sys.argv[2])
	else:
		PORT = 58000 +GN


	while 1:
		s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
		s.bind(("", PORT))
		s.listen(1)
		conn, addr = s.accept()	
		
		string = conn.recv(1024)
		data = string.split()
		if(data[0] == "AUT"):

			username = data[1]
			password = data[2]

			if(users.has_key(str(username))):
				if(users[str(username)] == str(password)):
					conn.sendall("AUR OK\n")
				else:
					conn.sendall("AUR NOK\n")
			else:
				users[str(username)] = str(password)
				conn.sendall("AUR NEW\n")

			print str(username) #imprime o username
			print str(password) #imprime a password

		elif(data[0] == "DLU"):
			print "DLU"
		elif(data[0] == "BCK"):
			print "BCK"
		elif(data[0] =="RST"):
			print "RST"
		elif(data[0] == "LSD"):
			print "LSD"
		elif(data[0] == "LSF"):
			print "LSF"
		elif(data[0] == "DEL"):
			print "DEL"
		elif(data[0] == "OUT"):
			print "OUT"

			break;
		else:
			print "ERR"
			print 'Received', repr(data)
		#conn.sendall(data)
		s.close()

parse()