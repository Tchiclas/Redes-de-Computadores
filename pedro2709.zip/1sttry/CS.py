'''
everything related to the central server 

'''
import socket
import sys

HOST = socket.gethostname()

#o valor generico sera 58000 mais o numero do grupo
GN = 63  #GN sera o numero do grupo


#dicionario com o username como key
users = {"12345":"aaaaaaaa"}        #utilizador para teste

#dicionario com o ip dos BS como key
BS = {}


#lista de diretorias 



#------chamar no inicio
def parse():

	#definir o PORT
	if(len(sys.argv) != 1 and sys.argv[1] == "-p"):
		PORT = int(sys.argv[2])
	else:
		PORT = 58000 +GN


	while 1:
		s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
		s.bind(("", PORT))
		s.listen(1)

		conn, addr = s.accept()	
		string = conn.recv(1024)
		data = string.split()
		if(data[0] == "AUT"):

			username = data[1]
			password = data[2]

			if(users.has_key(str(username))):
				if(users[str(username)] == str(password)):
					conn.sendall("AUR OK\n")
				else:
					conn.sendall("AUR NOK\n")
			else:
				users[str(username)] = str(password)
				conn.sendall("AUR NEW\n")

			print str(username) #imprime o username
			print str(password) #imprime a password

		elif(data[0] == "DLU"):
			print "DLU"
		elif(data[0] == "BCK"):
			print "BCK"
		elif(data[0] =="RST"):
			print "RST"
		elif(data[0] == "LSD"):

			counter = 0
			rec = ""
			file = open("backup_list.txt","r")
			for line in file:
				split = line.split()
				print split
				if(str(split[0]) == str(username)):
					counter = counter +1
					rec = rec +" "+ str(split[1])
			file.close()

			rec = "LDR "+ str(counter) +rec + "\n"
			conn.sendall(rec)
			print rec

		elif(data[0] == "LSF"):
			print "LSF"
		elif(data[0] == "DEL"):
			print "DEL"
		elif(data[0] == "OUT"):
			print "OUT"
			break;
		#elif(data[0] == "REG"):        ALGO DO GENERO MAS COM UDP NAO TCP
			#ip = data[1]
			#port = data[2]
			#bs[str(ip)] == int(port)
		else:
			print "ERR"
			print 'Received', repr(data)
		#conn.sendall(data)
		s.close()

parse()

#vai ter um ficheiro backup_list.txt e BS_list.txt 

#backup_list vai ter uma lista de todos os ficheiros 
#backedup do utilizador que esta logged in com o nome e sitio onde estao ? 


#BS_list lista dos backup servers registados tbm podia
#ser representado num dicionario com o ip e a porta
