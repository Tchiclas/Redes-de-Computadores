
'''
everything related to the user 

atencao!! nao estou a fazer nenhuma verificao de erros!

'''

#primeiro tenho de fazer o login, logo comeco por fazer a funcao que conecta os 2

import sys
import socket


global HOST
global PORT
global username
global password



#para escolher o que fazer 
def parse():
	list_str = [""]
	while (list_str[0] != "exit"):
		string = raw_input("choose an option: ")
		list_str = string.split()
		s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
		s.connect((HOST	, PORT))

		if(list_str[0] == "login"):

			username = str(list_str[1])
			password = str(list_str[2])

			#resposta do CS
			s.sendall("AUT "+username+" "+password+"\n")
			print  s.recv(16)

		elif(list_str[0] == "deluser"):
			print "deluser"
		elif(list_str[0] == "backup"):
			print "backup"
		elif(list_str[0] == "restore"):
			print "restore"
		elif(list_str[0] == "dirlist"):


			s.sendall("AUT "+username+" "+password+"\n")
			print  s.recv(16)
			s.close()
			
			s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
			s.connect((HOST	, PORT))

			s.sendall("LSD\n")
			print "dirlist"
			print s.recv(1024)

		elif(list_str[0] == "filelist"):
			print "filelist	"
		elif(list_str[0] == "delete"):
			print "delete"
		elif(list_str[0] == "logout"):
			print "logout"
		elif(list_str[0] == "exit"):
			print "exit"
			s.sendall("OUT")
			break;
		else:
			print "Invalid option!"

		s.close()


#HOST = socket.gethostbyname(str(sys.argv[2]))
#PORT = int(sys.argv[4])

if(len(sys.argv) == 3):
	if(sys.argv[1] == "-n"):
		HOST = socket.gethostbyname(str(sys.argv[2]))
		PORT = 58063
	elif(sys.argv[1] == "-p"):
		PORT = int(sys.argv[2])
		HOST = "localhost"
elif(len(sys.argv) == 4):
	HOST = socket.gethostbyname(str(sys.argv[2]))
	PORT = int(sys.argv[5])
else:
	PORT = 58063
	HOST = "localhost"





parse()

#print "CSname: "+ sys.argv[1] + " CSport: "+str(int(sys.argv[2])+1)