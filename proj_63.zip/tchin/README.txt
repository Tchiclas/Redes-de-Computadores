﻿Grupo 63 
Madalena Pedreira - 86466
Pedro Custódio - 86496
Rita Fernandes - 86508

Não foi feito o makefile para executar o programa, pois a linguagem usada (Python) já gera o executável.


Qualquer das extensões *.py são executadas usando o comando no terminal:

>>>$ python [nome-ficheiro].py

Em todas as execuções do programa, será necessário verificar que as pastas de CS e BS têm apenas os ficheiros CS.py
e BS.py para o programa funcionar como esperado.


